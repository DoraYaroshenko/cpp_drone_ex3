#include <drone_mapper/MappingAlgorithmImpl.h>
#include <drone_mapper/Units.h>
#include <drone_mapper/IMap3D.h>
#include <drone_mapper/CollisionUtils.h>

#include <mp-units/systems/si/math.h>

#include <algorithm>
#include <cmath>
#include <queue>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <optional>
#include <functional>
#include <array>
#include <limits>
#include <tuple>

namespace drone_mapper {

namespace {

// Voxel index in integer grid coordinates (one voxel per resolution unit).
struct VoxelIndex {
    int x;
    int y;
    int z;

    VoxelIndex operator+(const VoxelIndex& other) const {
        return {x + other.x, y + other.y, z + other.z};
    }

    VoxelIndex operator-(const VoxelIndex& other) const {
        return {x - other.x, y - other.y, z - other.z};
    }

    bool operator==(const VoxelIndex& other) const {
        return x == other.x && y == other.y && z == other.z;
    }
};

// Convert a world-space Position3D to a voxel index given a resolution.
// Each voxel spans [i*res, (i+1)*res) in each axis.
[[nodiscard]] inline VoxelIndex positionToVoxelIndex(const Position3D& pos, PhysicalLength resolution) {
    double res = resolution.force_numerical_value_in(cm);
    return {
        static_cast<int>(std::floor(pos.x.force_numerical_value_in(cm) / res)),
        static_cast<int>(std::floor(pos.y.force_numerical_value_in(cm) / res)),
        static_cast<int>(std::floor(pos.z.force_numerical_value_in(cm) / res))
    };
}

// Convert a voxel index center back to a world-space Position3D.
[[nodiscard]] inline Position3D voxelIndexToPosition(const VoxelIndex& vi, PhysicalLength resolution) {
    double res = resolution.force_numerical_value_in(cm);
    return {
        XLength((vi.x + 0.5) * res * x_extent[cm]),
        YLength((vi.y + 0.5) * res * y_extent[cm]),
        ZLength((vi.z + 0.5) * res * z_extent[cm])
    };
}

// ---------------------------------------------------------------------------
// Helpers: VoxelIndex hashing for use in unordered containers
// ---------------------------------------------------------------------------
struct VoxelIndexHash {
    std::size_t operator()(const VoxelIndex& v) const noexcept {
        auto h1 = std::hash<int>{}(v.x);
        auto h2 = std::hash<int>{}(v.y);
        auto h3 = std::hash<int>{}(v.z);
        return h1 ^ (h2 * 2654435761u) ^ (h3 * 40503u);
    }
};

using VoxelSet = std::unordered_set<VoxelIndex, VoxelIndexHash>;
using VoxelMap = std::unordered_map<VoxelIndex, VoxelIndex, VoxelIndexHash>;

// The 6 cardinal neighbour offsets in 3D grid space.
constexpr std::array<VoxelIndex, 6> kNeighbourOffsets = {{
    { 1,  0,  0},
    {-1,  0,  0},
    { 0,  1,  0},
    { 0, -1,  0},
    { 0,  0,  1},
    { 0,  0, -1},
}};

// ---------------------------------------------------------------------------
// Collision-safe voxel queries
// ---------------------------------------------------------------------------

/// Check whether a voxel is "passable" for the drone — i.e. the drone can
/// potentially move there. We require:
///   - Drone is fully in bounds
///   - No voxel inside the drone sphere is Occupied
/// Unmapped voxels are allowed (we'll scan before actually entering).
bool isVoxelPassable(const VoxelIndex& vi,
                     PhysicalLength resolution,
                     PhysicalLength radius,
                     const IMap3D& map) {
    Position3D centre = voxelIndexToPosition(vi, resolution);

    if (!CollisionUtils::isDroneFullyInBounds(map, centre, radius)) {
        return false;
    }

    double drone_r_cm = radius.numerical_value_in(cm);
    double res = resolution.numerical_value_in(cm);
    double step = std::max(1.0, res / 2.0);

    for (double dx = -drone_r_cm; dx <= drone_r_cm; dx += step) {
        for (double dy = -drone_r_cm; dy <= drone_r_cm; dy += step) {
            for (double dz = -drone_r_cm; dz <= drone_r_cm; dz += step) {
                if ((dx * dx + dy * dy + dz * dz) > (drone_r_cm * drone_r_cm)) continue;
                Position3D p{
                    centre.x + XLength(dx * x_extent[cm]),
                    centre.y + YLength(dy * y_extent[cm]),
                    centre.z + ZLength(dz * z_extent[cm])
                };
                if (!map.isInBounds(p)) return false;
                auto v = map.atVoxel(p);
                if (v == types::VoxelOccupancy::Occupied || v == types::VoxelOccupancy::PotentiallyOccupied) return false;
            }
        }
    }
    return true;
}

/// Stricter check: all voxels inside the drone sphere must be Empty.
/// Used before actually moving into a voxel.
bool isVoxelKnownSafe(const VoxelIndex& vi,
                      PhysicalLength resolution,
                      PhysicalLength radius,
                      const IMap3D& map) {
    Position3D centre = voxelIndexToPosition(vi, resolution);

    if (!CollisionUtils::isDroneFullyInBounds(map, centre, radius)) {
        return false;
    }

    double drone_r_cm = radius.numerical_value_in(cm);
    double res = resolution.numerical_value_in(cm);
    double step = std::max(1.0, res / 2.0);

    for (double dx = -drone_r_cm; dx <= drone_r_cm; dx += step) {
        for (double dy = -drone_r_cm; dy <= drone_r_cm; dy += step) {
            for (double dz = -drone_r_cm; dz <= drone_r_cm; dz += step) {
                if ((dx * dx + dy * dy + dz * dz) > (drone_r_cm * drone_r_cm)) continue;
                Position3D p{
                    centre.x + XLength(dx * x_extent[cm]),
                    centre.y + YLength(dy * y_extent[cm]),
                    centre.z + ZLength(dz * z_extent[cm])
                };
                if (!map.isInBounds(p)) return false;
                auto v = map.atVoxel(p);
                if (v != types::VoxelOccupancy::Empty) return false;
            }
        }
    }
    return true;
}

/// Gather all unmapped/potentially-occupied voxel positions inside the drone
/// sphere at a given voxel position. Returns voxel indices that need scanning.
std::vector<VoxelIndex> getUnknownVoxelsInSphere(const VoxelIndex& vi,
                                                  PhysicalLength resolution,
                                                  PhysicalLength radius,
                                                  const IMap3D& map) {
    std::vector<VoxelIndex> unknowns;
    Position3D centre = voxelIndexToPosition(vi, resolution);
    double drone_r_cm = radius.numerical_value_in(cm);
    double res = resolution.numerical_value_in(cm);
    double step = std::max(1.0, res / 2.0);

    VoxelSet seen;
    for (double dx = -drone_r_cm; dx <= drone_r_cm; dx += step) {
        for (double dy = -drone_r_cm; dy <= drone_r_cm; dy += step) {
            for (double dz = -drone_r_cm; dz <= drone_r_cm; dz += step) {
                if ((dx * dx + dy * dy + dz * dz) > (drone_r_cm * drone_r_cm)) continue;
                Position3D p{
                    centre.x + XLength(dx * x_extent[cm]),
                    centre.y + YLength(dy * y_extent[cm]),
                    centre.z + ZLength(dz * z_extent[cm])
                };
                if (!map.isInBounds(p)) continue;
                auto v = map.atVoxel(p);
                if (v == types::VoxelOccupancy::Unmapped) {
                    VoxelIndex idx = positionToVoxelIndex(p, resolution);
                    if (!seen.count(idx)) {
                        seen.insert(idx);
                        unknowns.push_back(idx);
                    }
                }
            }
        }
    }
    return unknowns;
}

// ---------------------------------------------------------------------------
// Compute scan orientations for unmapped voxels near a position
// ---------------------------------------------------------------------------
Orientation scanOrientationToVoxel(const Position3D& drone_pos,
                                   const Orientation& drone_heading,
                                   const VoxelIndex& target_voxel,
                                   PhysicalLength resolution) {
    Position3D target = voxelIndexToPosition(target_voxel, resolution);

    double dx = (target.x - drone_pos.x).numerical_value_in(cm);
    double dy = (target.y - drone_pos.y).numerical_value_in(cm);
    double dz = (target.z - drone_pos.z).numerical_value_in(cm);

    double horiz = std::sqrt(dx * dx + dy * dy);

    HorizontalAngle abs_h(si::atan2(dy * cm, dx * cm));
    AltitudeAngle abs_v(si::atan2(dz * cm, horiz * cm));

    HorizontalAngle h_diff = abs_h - drone_heading.horizontal;
    while (h_diff > 180.0 * horizontal_angle[deg]) h_diff -= 360.0 * horizontal_angle[deg];
    while (h_diff < -180.0 * horizontal_angle[deg]) h_diff += 360.0 * horizontal_angle[deg];

    AltitudeAngle v_diff = abs_v - drone_heading.altitude;
    while (v_diff > 180.0 * altitude_angle[deg]) v_diff -= 360.0 * altitude_angle[deg];
    while (v_diff < -180.0 * altitude_angle[deg]) v_diff += 360.0 * altitude_angle[deg];

    return Orientation{h_diff, v_diff};
}

/// Generate scan orientations for all unmapped voxels within a given range
/// (in voxel units) of the drone.
std::vector<Orientation> generateScansForUnmapped(const Position3D& drone_pos,
                                                   const Orientation& drone_heading,
                                                   PhysicalLength resolution,
                                                   const IMap3D& map,
                                                   int scan_range) {
    std::vector<Orientation> scans;
    VoxelIndex drone_vi = positionToVoxelIndex(drone_pos, resolution);

    for (int dx = -scan_range; dx <= scan_range; ++dx) {
        for (int dy = -scan_range; dy <= scan_range; ++dy) {
            for (int dz = -scan_range; dz <= scan_range; ++dz) {
                VoxelIndex target{drone_vi.x + dx, drone_vi.y + dy, drone_vi.z + dz};
                Position3D p = voxelIndexToPosition(target, resolution);
                if (!map.isInBounds(p)) continue;
                auto v = map.atVoxel(p);
                if (v == types::VoxelOccupancy::Unmapped) {
                    Orientation orient = scanOrientationToVoxel(drone_pos, drone_heading, target, resolution);
                    // Deduplicate close orientations
                    bool exists = false;
                    for (const auto& existing : scans) {
                        if (std::abs((existing.horizontal - orient.horizontal).numerical_value_in(deg)) < 1.0 &&
                            std::abs((existing.altitude - orient.altitude).numerical_value_in(deg)) < 1.0) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        scans.push_back(orient);
                    }
                }
            }
        }
    }
    return scans;
}

// ---------------------------------------------------------------------------
// BFS frontier search using passable (not strictly known-safe) expansion.
// A "frontier" is a passable voxel that is adjacent to an unmapped voxel
// and is NOT the start voxel (so the drone actually has to move).
// If no moveable frontier is found but the start itself has unmapped
// neighbours, we return the start as a fallback.
// ---------------------------------------------------------------------------
struct FrontierResult {
    bool found = false;
    VoxelIndex target{0, 0, 0};
    bool needs_move = false; // true if target != drone position
};

FrontierResult findFrontier(const Position3D& drone_pos,
                            PhysicalLength resolution,
                            PhysicalLength radius,
                            const IMap3D& map) {
    VoxelIndex start = positionToVoxelIndex(drone_pos, resolution);

    std::queue<VoxelIndex> bfs_queue;
    VoxelSet visited;

    bfs_queue.push(start);
    visited.insert(start);

    bool start_is_frontier = false;

    while (!bfs_queue.empty()) {
        VoxelIndex current = bfs_queue.front();
        bfs_queue.pop();

        // Check if this voxel has any unmapped neighbours
        bool has_unmapped_neighbour = false;
        for (const auto& offset : kNeighbourOffsets) {
            VoxelIndex nb = current + offset;
            Position3D nb_pos = voxelIndexToPosition(nb, resolution);
            if (!map.isInBounds(nb_pos)) continue;

            auto v = map.atVoxel(nb_pos);
            if (v == types::VoxelOccupancy::Unmapped) {
                has_unmapped_neighbour = true;
                break;
            }
        }

        if (has_unmapped_neighbour) {
            if (current == start) {
                // Remember that start is a frontier, but keep looking for one
                // that requires movement
                start_is_frontier = true;
            } else {
                return {true, current, true};
            }
        }

        // Expand to neighbours that are passable (not just known-safe)
        for (const auto& offset : kNeighbourOffsets) {
            VoxelIndex nb = current + offset;
            if (visited.count(nb)) continue;
            visited.insert(nb);

            if (isVoxelPassable(nb, resolution, radius, map)) {
                bfs_queue.push(nb);
            }
        }
    }

    // If we found no remote frontier but start itself is one, return it
    if (start_is_frontier) {
        return {true, start, false};
    }

    return {false, {0, 0, 0}, false};
}

// ---------------------------------------------------------------------------
// A* pathfinding using passable voxels (not just known-safe).
// ---------------------------------------------------------------------------

struct AStarNode {
    VoxelIndex pos;
    double g_cost;
    double f_cost;

    bool operator>(const AStarNode& other) const {
        return f_cost > other.f_cost;
    }
};

double heuristic(const VoxelIndex& a, const VoxelIndex& b) {
    return std::abs(a.x - b.x) + std::abs(a.y - b.y) + std::abs(a.z - b.z);
}

std::vector<VoxelIndex> aStarPath(const VoxelIndex& start,
                                   const VoxelIndex& goal,
                                   PhysicalLength resolution,
                                   PhysicalLength radius,
                                   const IMap3D& map) {
    using PQ = std::priority_queue<AStarNode, std::vector<AStarNode>, std::greater<AStarNode>>;
    PQ open;
    std::unordered_map<VoxelIndex, double, VoxelIndexHash> g_costs;
    VoxelMap came_from;

    open.push({start, 0.0, heuristic(start, goal)});
    g_costs[start] = 0.0;

    while (!open.empty()) {
        AStarNode current = open.top();
        open.pop();

        if (current.pos == goal) {
            std::vector<VoxelIndex> path;
            VoxelIndex node = goal;
            while (!(node == start)) {
                path.push_back(node);
                node = came_from[node];
            }
            path.push_back(start);
            std::reverse(path.begin(), path.end());
            return path;
        }

        if (current.g_cost > g_costs[current.pos] + 1e-9) {
            continue;
        }

        for (const auto& offset : kNeighbourOffsets) {
            VoxelIndex nb = current.pos + offset;

            // Path through passable voxels (no occupied in drone sphere)
            if (!isVoxelPassable(nb, resolution, radius, map)) {
                continue;
            }

            double tentative_g = current.g_cost + 1.0;
            auto it = g_costs.find(nb);
            if (it != g_costs.end() && tentative_g >= it->second) {
                continue;
            }

            g_costs[nb] = tentative_g;
            came_from[nb] = current.pos;
            open.push({nb, tentative_g, tentative_g + heuristic(nb, goal)});
        }
    }

    return {};
}

// ---------------------------------------------------------------------------
// State machine for the Frontier Exploration algorithm
// ---------------------------------------------------------------------------

enum class SweepPhase {
    ScanSurroundings,  // Generate scans for nearby unmapped voxels
    ExecuteScans,      // Drain pending scan queue
    FindFrontier,      // BFS to find nearest unmapped frontier
    PlanPath,          // A* path to frontier
    FollowPath,        // Execute movement commands along path
    ScanBeforeMove,    // Scan unknown voxels in drone sphere at next path step
    Finished,
};

struct SweepState {
    SweepPhase phase = SweepPhase::ScanSurroundings;
    std::vector<Orientation> pending_scans;
    std::vector<VoxelIndex> planned_path;
    std::size_t path_index = 0;
    VoxelIndex frontier_target{0, 0, 0};
    int stall_count = 0;
    VoxelIndex last_frontier{-999, -999, -999};
    SweepPhase return_after_scans = SweepPhase::FindFrontier; // where to go after ExecuteScans
    bool initial_scan_done = false;
};

std::unordered_map<const void*, SweepState> g_sweep_states;

// ---------------------------------------------------------------------------
// Phase handlers
// ---------------------------------------------------------------------------

std::optional<types::MappingStepCommand> handleScanSurroundings(
    SweepState& sweep,
    const Position3D& pos,
    const Orientation& heading,
    PhysicalLength resolution,
    const IMap3D& map) {

    // On first call, do a broad scan (range 5) to map nearby space.
    // On subsequent calls, use a smaller range.
    int range = sweep.initial_scan_done ? 3 : 5;
    sweep.initial_scan_done = true;

    sweep.pending_scans = generateScansForUnmapped(pos, heading, resolution, map, range);

    if (!sweep.pending_scans.empty()) {
        sweep.return_after_scans = SweepPhase::FindFrontier;
        sweep.phase = SweepPhase::ExecuteScans;
    } else {
        sweep.phase = SweepPhase::FindFrontier;
    }
    return std::nullopt;
}

std::optional<types::MappingStepCommand> handleExecuteScans(SweepState& sweep) {
    if (!sweep.pending_scans.empty()) {
        types::MappingStepCommand cmd;
        cmd.scan_orientation = sweep.pending_scans.back();
        sweep.pending_scans.pop_back();
        cmd.status = types::AlgorithmStatus::Working;
        return cmd;
    }
    sweep.phase = sweep.return_after_scans;
    return std::nullopt;
}

std::optional<types::MappingStepCommand> handleFindFrontier(
    SweepState& sweep,
    const Position3D& pos,
    PhysicalLength resolution,
    PhysicalLength radius,
    const IMap3D& map) {

    auto result = findFrontier(pos, resolution, radius, map);
    if (result.found) {
        sweep.frontier_target = result.target;

        // Stall detection
        if (sweep.frontier_target == sweep.last_frontier) {
            sweep.stall_count++;
        } else {
            sweep.stall_count = 0;
            sweep.last_frontier = sweep.frontier_target;
        }
        if (sweep.stall_count > 50) {
            sweep.phase = SweepPhase::Finished;
            return std::nullopt;
        }

        if (!result.needs_move) {
            // We're at the frontier; scan again and the map should update,
            // then next time findFrontier will find a remote one
            sweep.phase = SweepPhase::ScanSurroundings;
        } else {
            sweep.phase = SweepPhase::PlanPath;
        }
    } else {
        sweep.phase = SweepPhase::Finished;
    }
    return std::nullopt;
}

std::optional<types::MappingStepCommand> handlePlanPath(
    SweepState& sweep,
    const Position3D& pos,
    PhysicalLength resolution,
    PhysicalLength radius,
    const IMap3D& map) {

    VoxelIndex start = positionToVoxelIndex(pos, resolution);

    if (start == sweep.frontier_target) {
        // Already here — scan and find a new target
        sweep.phase = SweepPhase::ScanSurroundings;
        return std::nullopt;
    }

    auto path = aStarPath(start, sweep.frontier_target, resolution, radius, map);
    if (path.empty()) {
        // Can't reach this frontier — scan more and try again
        sweep.phase = SweepPhase::ScanSurroundings;
        return std::nullopt;
    }

    sweep.planned_path = std::move(path);
    sweep.path_index = 1; // Skip start
    sweep.phase = SweepPhase::FollowPath;
    return std::nullopt;
}

/// Before moving to a path step, check if we need to scan unknown voxels
/// in the drone sphere at that position. If so, scan from current position
/// toward those unknowns.
std::optional<types::MappingStepCommand> handleScanBeforeMove(
    SweepState& sweep,
    const Position3D& pos,
    const Orientation& heading,
    PhysicalLength resolution,
    PhysicalLength radius,
    const IMap3D& map) {

    if (sweep.path_index >= sweep.planned_path.size()) {
        sweep.phase = SweepPhase::FollowPath;
        return std::nullopt;
    }

    VoxelIndex next_vi = sweep.planned_path[sweep.path_index];
    auto unknowns = getUnknownVoxelsInSphere(next_vi, resolution, radius, map);

    if (unknowns.empty()) {
        // All clear — proceed to move
        sweep.phase = SweepPhase::FollowPath;
        return std::nullopt;
    }

    // Generate scans toward the unknown voxels
    sweep.pending_scans.clear();
    for (const auto& unk : unknowns) {
        Orientation orient = scanOrientationToVoxel(pos, heading, unk, resolution);
        bool exists = false;
        for (const auto& existing : sweep.pending_scans) {
            if (std::abs((existing.horizontal - orient.horizontal).numerical_value_in(deg)) < 1.0 &&
                std::abs((existing.altitude - orient.altitude).numerical_value_in(deg)) < 1.0) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            sweep.pending_scans.push_back(orient);
        }
    }

    if (!sweep.pending_scans.empty()) {
        sweep.return_after_scans = SweepPhase::FollowPath;
        sweep.phase = SweepPhase::ExecuteScans;
    } else {
        sweep.phase = SweepPhase::FollowPath;
    }
    return std::nullopt;
}

std::optional<types::MappingStepCommand> handleFollowPath(
    SweepState& sweep,
    const Position3D& pos,
    const Orientation& heading,
    PhysicalLength resolution,
    PhysicalLength radius,
    const IMap3D& map,
    const types::DroneConfigData& drone_config) {

    if (sweep.path_index >= sweep.planned_path.size()) {
        // Path completed — scan surroundings at the new position
        sweep.phase = SweepPhase::ScanSurroundings;
        return std::nullopt;
    }

    VoxelIndex next_vi = sweep.planned_path[sweep.path_index];

    // If the next voxel has unknown voxels in the drone sphere, scan first
    if (!isVoxelKnownSafe(next_vi, resolution, radius, map)) {
        // Check if it's still passable (no occupied voxels)
        if (!isVoxelPassable(next_vi, resolution, radius, map)) {
            // Path is blocked by a newly-discovered wall — replan
            sweep.phase = SweepPhase::ScanSurroundings;
            return std::nullopt;
        }
        // Scan the unknowns before entering
        sweep.phase = SweepPhase::ScanBeforeMove;
        return std::nullopt;
    }

    Position3D target_pos = voxelIndexToPosition(next_vi, resolution);

    double dx = (target_pos.x - pos.x).numerical_value_in(cm);
    double dy = (target_pos.y - pos.y).numerical_value_in(cm);
    double dz = (target_pos.z - pos.z).numerical_value_in(cm);

    types::MappingStepCommand cmd;
    cmd.status = types::AlgorithmStatus::Working;

    // Handle elevation change first
    if (std::abs(dz) > 0.01) {
        PhysicalLength abs_dist(std::abs(dz) * cm);
        PhysicalLength step = (abs_dist < drone_config.max_elevate) ? abs_dist : drone_config.max_elevate;
        cmd.movement = types::MovementCommand{
            types::MovementCommandType::Elevate, {}, {}, (dz > 0) ? step : -step
        };
        if (abs_dist <= drone_config.max_elevate + 0.001 * cm && std::abs(dx) < 0.01 && std::abs(dy) < 0.01) {
            sweep.path_index++;
        }
        return cmd;
    }

    // Handle horizontal movement
    double horiz_dist = std::sqrt(dx * dx + dy * dy);
    if (horiz_dist > 0.01) {
        HorizontalAngle desired_h(si::atan2(dy * cm, dx * cm));
        HorizontalAngle current_h = heading.horizontal;
        HorizontalAngle h_diff = desired_h - current_h;

        while (h_diff > 180.0 * horizontal_angle[deg]) h_diff -= 360.0 * horizontal_angle[deg];
        while (h_diff < -180.0 * horizontal_angle[deg]) h_diff += 360.0 * horizontal_angle[deg];

        double abs_diff = std::abs(h_diff.numerical_value_in(deg));

        if (abs_diff > 0.5) {
            HorizontalAngle max_rot(drone_config.max_rotate.numerical_value_in(deg) * horizontal_angle[deg]);
            HorizontalAngle abs_angle(abs_diff * horizontal_angle[deg]);
            HorizontalAngle step_angle = (abs_angle < max_rot) ? abs_angle : max_rot;

            cmd.movement = types::MovementCommand{
                types::MovementCommandType::Rotate,
                h_diff.numerical_value_in(deg) > 0 ? types::RotationDirection::Left : types::RotationDirection::Right,
                step_angle,
                {}
            };
            return cmd;
        }

        PhysicalLength adv_dist(horiz_dist * cm);
        PhysicalLength step = (adv_dist < drone_config.max_advance) ? adv_dist : drone_config.max_advance;
        cmd.movement = types::MovementCommand{
            types::MovementCommandType::Advance, {}, {}, step
        };
        if (adv_dist <= drone_config.max_advance + 0.001 * cm) {
            sweep.path_index++;
        }
        return cmd;
    }

    // Already at the voxel
    sweep.path_index++;
    return std::nullopt;
}

} // namespace

MappingAlgorithmImpl::~MappingAlgorithmImpl() {
    g_sweep_states.erase(this);
}

types::MappingStepCommand MappingAlgorithmImpl::nextStep(const types::DroneState& state,
                                                         const types::LidarScanResult* /*latest_scan*/) {
    auto& sweep = g_sweep_states[this];
    const Position3D& pos = state.position;
    const Orientation& heading = state.heading;
    PhysicalLength resolution = output_map_.getMapConfig().resolution;
    PhysicalLength radius = drone_config_.radius;

    while (true) {
        std::optional<types::MappingStepCommand> cmd_opt;

        switch (sweep.phase) {
            case SweepPhase::ScanSurroundings:
                cmd_opt = handleScanSurroundings(sweep, pos, heading, resolution, output_map_);
                break;
            case SweepPhase::ExecuteScans:
                cmd_opt = handleExecuteScans(sweep);
                break;
            case SweepPhase::FindFrontier:
                cmd_opt = handleFindFrontier(sweep, pos, resolution, radius, output_map_);
                break;
            case SweepPhase::PlanPath:
                cmd_opt = handlePlanPath(sweep, pos, resolution, radius, output_map_);
                break;
            case SweepPhase::FollowPath:
                cmd_opt = handleFollowPath(sweep, pos, heading, resolution, radius, output_map_, drone_config_);
                break;
            case SweepPhase::ScanBeforeMove:
                cmd_opt = handleScanBeforeMove(sweep, pos, heading, resolution, radius, output_map_);
                break;
            case SweepPhase::Finished: {
                types::MappingStepCommand cmd;
                cmd.status = types::AlgorithmStatus::Finished;
                return cmd;
            }
        }

        if (cmd_opt) {
            return *cmd_opt;
        }
    }
}

} // namespace drone_mapper
